// === server.js (actualizado) ===

const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const fetch = require('node-fetch');

const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log("✅ Conectado a MongoDB Atlas");
}).catch((err) => {
  console.error("❌ Error conectando a MongoDB:", err.message);
});

// Esquema para predicciones finales
const datosSchema = new mongoose.Schema({
  vidas: Number,
  puntaje: Number,
  tiempo: Number,
  nivel: Number,
  resultado: Number,
});
const Dato = mongoose.model('proyecto', datosSchema);

// NUEVO esquema para predicciones en vivo
const enVivoSchema = new mongoose.Schema({
  vidas: Number,
  puntaje: Number,
  tiempo: Number,
  nivel: Number,
  resultado: Number,
  timestamp: { type: Date, default: Date.now }
});
const DatoEnVivo = mongoose.model('en_vivo', enVivoSchema);

// Ruta original: guarda predicción final
app.post("/guardar", async (req, res) => {
  const datos = req.body;
  try {
    const response = await fetch("https://octasf-hcip.hf.space/predecir", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(datos)
    });
    const resultado = await response.json();
    const nuevo = new Dato({ ...datos, resultado: resultado.resultado });
    await nuevo.save();
    res.json(resultado);
  } catch (error) {
    res.status(500).json({ error: "Error al guardar predicción" });
  }
});

// Nueva ruta para obtener datos guardados
app.get("/ver_datos", async (req, res) => {
  try {
    const datos = await Dato.find();
    res.json(datos);
  } catch (error) {
    res.status(500).json({ error: "Error al obtener los datos" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servidor escuchando en puerto ${PORT}`);
});
