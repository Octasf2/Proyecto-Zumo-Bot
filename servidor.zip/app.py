import joblib
import numpy as np

# Cargar el modelo .joblib
modelo = joblib.load('modelo_ensemble1.joblib')

def predecir(vidas, puntaje, tiempo, nivel):
    # Preparar los datos para la predicción
    X = np.array([[vidas, puntaje, tiempo, nivel]])
    
    # Realizar la predicción
    prediccion = modelo.predict(X)[0]
    
    return prediccion

# Ejemplo de uso:
if __name__ == "__main__":
    vidas = 3
    puntaje = 80
    tiempo = 30
    nivel = 1
    
    resultado = predecir(vidas, puntaje, tiempo, nivel)
    print(f"Predicción: {resultado}")
